# Reel Monster (Level 1 – manual) · Aditya Kumar
Floating 👾 bubble over Instagram/YouTube. Tap it after each reel (+1). It grows and says funny lines.
Main screen: today's count, minutes lost (≈25 s per reel) and last 7 days. Works offline, no login; counts are stored in SharedPreferences so they survive restarts.

## Build (needs Android SDK – not available where this was generated, so APK is NOT included)
1. Install Android Studio (or command-line tools + JDK 17). Open this folder, let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run  — or `gradle assembleDebug` and install `app/build/outputs/apk/debug/app-debug.apk`.
3. Open the app → "Allow display over other apps" → "Show monster".
Level 2 (auto counting via AccessibilityService) is not implemented.
