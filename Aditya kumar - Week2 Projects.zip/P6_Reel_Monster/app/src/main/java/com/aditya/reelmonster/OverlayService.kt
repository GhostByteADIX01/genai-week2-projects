package com.aditya.reelmonster
import android.app.Service
import android.content.*
import android.graphics.*
import android.os.IBinder
import android.view.*
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

/** Level 1 (manual): floating monster, tap it after each reel. Built for Aditya Kumar. */
object Store {
    fun key(d: Date = Date()) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(d)
    fun p(c: Context) = c.getSharedPreferences("reels", Context.MODE_PRIVATE)
    fun today(c: Context) = p(c).getInt(key(), 0)
    fun add(c: Context) = p(c).edit().putInt(key(), today(c) + 1).apply()
    fun last7(c: Context) = (6 downTo 0).map { val cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, -it); p(c).getInt(key(cal.time), 0) }
}
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var tv: TextView
    private val lines = listOf("Tap me +1", "Yum! Tasty reel.", "Burp. Your homework says hi.", "I'm getting fat...", "Go touch grass!", "Still scrolling?!")
    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tv = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#E5499B")); setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(24, 16, 24, 16)
            setOnClickListener { Store.add(context); refresh() }
        }
        refresh()
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 300
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - sx) > 15 || Math.abs(e.rawY - sy) > 15) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(tv, lp) } }
                MotionEvent.ACTION_UP -> if (!moved) v.performClick()
            }; true }
        wm.addView(tv, lp)
    }
    private fun refresh() { val n = Store.today(this); tv.text = "👾 $n\n" + lines[(n / 5).coerceAtMost(lines.size - 1)]; tv.textSize = (14 + n / 10).coerceAtMost(30).toFloat() }
    override fun onDestroy() { wm.removeView(tv) }
}
