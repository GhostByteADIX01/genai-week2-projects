package com.aditya.reelmonster
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48); gravity = Gravity.CENTER_HORIZONTAL }
        info = TextView(this).apply { textSize = 22f; gravity = Gravity.CENTER }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        l.addView(TextView(this).apply { text = "👾 Reel Monster\nby Aditya Kumar"; textSize = 26f; gravity = Gravity.CENTER })
        l.addView(info)
        l.addView(btn("1. Allow display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
        l.addView(btn("2. Show monster") { if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java)) else Toast.makeText(this, "Allow overlay first", Toast.LENGTH_SHORT).show() })
        l.addView(btn("Hide monster") { stopService(Intent(this, OverlayService::class.java)) })
        setContentView(l)
    }
    override fun onResume() {
        super.onResume()
        val d = Store.last7(this); val n = d.last()
        info.text = "Today: $n reels · ${n * 25 / 60} min lost\nLast 7 days: ${d.joinToString(" · ")}"
    }
}
