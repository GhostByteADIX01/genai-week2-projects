Install: copy the `viva/` folder to `~/.claude/skills/viva/` (Claude Code) or zip it and upload under Settings → Skills. Start a NEW session and type `/viva samples/thermo-notes.txt`.
