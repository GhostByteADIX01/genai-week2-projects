---
name: viva
description: Run a viva (oral exam) from the user's study notes. Use when the user types /viva or asks to be quizzed, tested or examined orally on notes, a chapter, or a PDF/text file. Asks 5 questions one at a time, probes weak answers, scores out of 5, and says which part to revise.
---
# /viva — oral exam from your notes
Author: Aditya Kumar

## Steps
1. Read the file/text the user gave (if none, ask for it). Do not ask more than one setup question.
2. Pick 5 questions of rising difficulty: 2 definition, 2 "why/how", 1 application. Cover different parts of the notes.
3. Ask ONE question at a time, numbered `Q1.`–`Q5.`. Wait for the answer. Never show the answer key early.
4. After each answer reply as **Examiner:** in 1–2 sentences:
   - Correct → say so briefly, move on.
   - Partly right → say "Partly." name what is right, then ask a pointed follow-up (counts once; follow-up answer can raise credit to full or half).
   - Wrong → give a hint, not the answer, then move on.
5. Score: 1 = correct, 0.5 = partly, 0 = wrong.
6. End with `Score: X/5.` then 2–3 bullets: strongest topic, weakest topic, and exact page/section of the notes to revise.

## Rules
- Examine only on the notes provided; no outside trivia.
- Keep a firm, fair, short examiner tone. No long explanations until the end.
- If the notes are too short for 5 questions, ask fewer and say so.
