# Test inputs (use these 3 to check the skill)
1. thermo-notes.txt — Carnot efficiency, entropy, first law.
2. ohm-notes.txt — Ohm's law, resistivity, series/parallel.
3. photosynthesis.txt — light reactions vs Calvin cycle.
Compare: ask the same "quiz me" task WITHOUT the skill — the plain chat usually asks all questions at once, never probes weak answers and gives no revise-page pointer. Write your observed difference in compare.md.
