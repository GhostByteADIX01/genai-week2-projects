const $=i=>document.getElementById(i),ago=ms=>{const m=Math.round(ms/6e4);return m<60?m+' min':m<1440?Math.round(m/60)+' h':Math.round(m/1440)+' days'};
const host=u=>{try{return new URL(u).hostname}catch(e){return u}};
async function load(){const tabs=(await chrome.tabs.query({})).sort((a,b)=>(a.lastAccessed||0)-(b.lastAccessed||0));const{keep=[],sessions={}}=await chrome.storage.local.get(['keep','sessions']);
 const n=tabs.length,asleep=tabs.filter(t=>t.discarded).length;$('h').textContent=n+' tabs open';$('s').textContent=asleep+' asleep';$('g').textContent=n<10?'😊':n<25?'😐':'😡';
 $('list').innerHTML='';tabs.forEach(t=>{const kept=keep.includes(host(t.url)),d=document.createElement('div');d.className='r'+(t.discarded?' z':'');
  d.innerHTML=`<span title="${t.url}">${t.discarded?'💤 ':''}${t.title||t.url}</span><small>${kept?'Keep':ago(Date.now()-(t.lastAccessed||Date.now()))}</small>`;
  const b=document.createElement('button');b.className='k';b.textContent=kept?'unkeep':'keep';b.onclick=async()=>{const k=kept?keep.filter(x=>x!=host(t.url)):[...keep,host(t.url)];await chrome.storage.local.set({keep:k});load()};d.appendChild(b);
  d.firstChild.onclick=()=>chrome.tabs.update(t.id,{active:true});$('list').appendChild(d)});
 $('ses').innerHTML='';Object.keys(sessions).forEach(k=>{const b=document.createElement('button');b.textContent='Restore '+k;b.onclick=()=>sessions[k].forEach(u=>chrome.tabs.create({url:u,active:false}));$('ses').appendChild(b)})}
$('feed').onclick=async()=>{const{keep=[]}=await chrome.storage.local.get('keep'),lim=(+$('m').value||30)*6e4;let c=0;
 for(const t of await chrome.tabs.query({})){if(t.active||t.pinned||t.audible||t.discarded||keep.includes(host(t.url)))continue;if(Date.now()-(t.lastAccessed||Date.now())<lim)continue;try{await chrome.tabs.discard(t.id);c++}catch(e){}}
 await load();$('g').textContent='😋';$('s').textContent+=` · ate ${c} tabs`};
$('ss').onclick=async()=>{const{sessions={}}=await chrome.storage.local.get('sessions');sessions[new Date().toLocaleString()]=(await chrome.tabs.query({})).map(t=>t.url).filter(u=>/^https?:/.test(u));await chrome.storage.local.set({sessions});load()};
load();
