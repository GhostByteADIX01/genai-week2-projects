const $=i=>document.getElementById(i);let cur={colors:[],fonts:[]};
function scan(){const area={},fonts={};document.querySelectorAll('body, body *').forEach(e=>{const r=e.getBoundingClientRect();if(r.width<2||r.height<2||r.bottom<0)return;const s=getComputedStyle(e);if(s.display=='none'||s.visibility=='hidden')return;
 const a=Math.min(r.width,innerWidth)*Math.min(r.height,2000),hasText=[...e.childNodes].some(n=>n.nodeType==3&&n.textContent.trim());
 const bg=s.backgroundColor;if(bg&&!/, 0\)$|transparent/.test(bg))area[bg]=(area[bg]||0)+a;
 if(hasText){const col=s.color;area[col]=(area[col]||0)+a*.15;const k=s.fontFamily.split(',')[0].replace(/["']/g,'').trim()+'|'+s.fontWeight+'|'+s.fontSize;fonts[k]=(fonts[k]||0)+1}});
 return{area,fonts}}
const hex=c=>{const m=c.match(/[\d.]+/g).map(Number);return'#'+m.slice(0,3).map(v=>Math.round(v).toString(16).padStart(2,'0')).join('')};
const say=t=>{$('msg').textContent=t;setTimeout(()=>$('msg').textContent='',1500)},copy=t=>{navigator.clipboard.writeText(t);say('Copied '+t)};
function show(k){cur=k;$('cols').innerHTML='';k.colors.forEach(c=>{const d=document.createElement('div');d.className='sw';d.innerHTML=`<i style="background:${c}"></i>${c}`;d.onclick=()=>copy(c);$('cols').appendChild(d)});
 $('fonts').innerHTML='';k.fonts.forEach(f=>{const d=document.createElement('div');d.className='f';d.textContent=`${f.family} · ${f.weight} · ${f.size}`;d.onclick=()=>copy(`font-family:${f.family};font-weight:${f.weight};font-size:${f.size}`);$('fonts').appendChild(d)})}
const css=k=>':root{\n'+k.colors.map((c,i)=>`  --color-${i+1}: ${c};`).join('\n')+'\n'+k.fonts.map((f,i)=>`  --font-${i+1}: "${f.family}", sans-serif; /* ${f.weight} ${f.size} */`).join('\n')+'\n}';
async function kits(){const{kits={}}=await chrome.storage.local.get('kits');$('kits').innerHTML='';Object.keys(kits).forEach(n=>{const d=document.createElement('div');d.className='f';d.textContent=n+'  (load)';d.onclick=()=>show(kits[n]);const x=document.createElement('span');x.textContent='  ✕';x.onclick=async e=>{e.stopPropagation();delete kits[n];await chrome.storage.local.set({kits});kits_()};d.appendChild(x);$('kits').appendChild(d)})}
const kits_=kits;
$('sv').onclick=async()=>{const n=$('nm').value.trim()||'kit-'+Date.now();const{kits={}}=await chrome.storage.local.get('kits');kits[n]=cur;await chrome.storage.local.set({kits});say('Saved '+n);kits_()};
$('cp').onclick=()=>copy(css(cur));
(async()=>{kits_();try{const[t]=await chrome.tabs.query({active:true,currentWindow:true});const[{result}]=await chrome.scripting.executeScript({target:{tabId:t.id},func:scan});
 const cols=Object.entries(result.area).map(([c,a])=>[hex(c),a]).reduce((m,[h,a])=>(m[h]=(m[h]||0)+a,m),{});
 const colors=Object.entries(cols).sort((a,b)=>b[1]-a[1]).slice(0,8).map(e=>e[0]);
 const fonts=Object.entries(result.fonts).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([k])=>{const[family,weight,size]=k.split('|');return{family,weight,size}});show({colors,fonts})}catch(e){say('Cannot scan this page')}})();
