# Week 2 Projects — Aditya Kumar
| Folder | How to run |
|---|---|
| P1_PDF_Studio | open index.html (offline) |
| P5_Scribbly_Notes | open index.html; Save images / Print→PDF |
| P6_Reel_Monster | Android source (Level 1) — build with Android Studio, see its README |
| P8_Auto_Rally | open index.html (phone: host or open file; installs offline via sw.js when served) |
| P13_Style_Spy, P14_Tab_Goblin | chrome://extensions → Developer mode → Load unpacked → pick the folder |
| P16_Your_Own_Skill | copy viva/ into your agent's skills folder |
| P17_Same_Page_New_Design | before.html vs after.html |
