# prompts.md — Aditya Kumar
1. "Build 8 Week-2 projects (P1 PDF Studio, P5 Scribbly Notes, P6 Reel Monster, P8 Auto Rally, P13 Style Spy, P14 Tab Goblin, P16 Your Own Skill, P17 Same Page New Design), offline, with my name in them, zipped under 10 MB."
Tip: for your report write your own follow-up prompts here as you test and improve each project.
