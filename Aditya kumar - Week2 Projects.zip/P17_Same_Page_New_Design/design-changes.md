# 3 design changes (Aditya Kumar)
1. **Gradient dark background + large bold title** – creates a clear focal point and a "fest" mood; the eye lands on the name first.
2. **Yellow pill button with hover lift** – the default blue underlined link looked like text; a high-contrast button makes the one action obvious.
3. **Highlights as cards in a responsive grid** – a plain bullet list becomes scannable chunks that stack on a phone (`auto-fit` columns) and stay readable.
Words in both files are identical. Skill used: frontend-design principles (distinct type, intentional palette, no default look). Replace/add notes if you used Impeccable.
